<?php
    // Heading
    $_['heading_title']         = 'Recipe';
    // Text
    $_['text_success']          = 'Success: You have modified Recipes!';
    $_['text_list']             = 'Recipe list';
    $_['text_add']              = 'Add Recipe';
    $_['text_edit']             = 'Edit Recipe';
    $_['text_default']          = 'Default';
    // Column
    $_['column_recipe']         = 'Recipes';
    $_['column_name']           = 'Name';
    $_['column_author']         = 'Author';
    $_['column_requeriment']    = 'Requeriments';
    $_['column_ingredient']     = 'Ingredients'; 
    $_['column_prep_time']      = 'Praparation Time'; 
    $_['column_cook_time']      = 'Process Time'; 
    $_['column_preparation']    = 'Preparation'; 
    $_['column_tip']            = 'Tips';
    $_['column_image']          = 'Image';
    $_['column_action']         = 'Action';
    // Entry
    $_['entry_name']            = 'Name';
    $_['entry_author']          = 'Author Name';
    $_['entry_description']     = 'Description';
    $_['entry_requeriment']     = 'Requeriment';
    $_['entry_ingredient']      = 'Ingredient';
    $_['entry_prep_time']       = 'Preparation Time';
    $_['entry_cook_time']       = 'Process Time';
    $_['entry_preparation']     = 'Preparation';
    $_['entry_tip']             = 'Tip';
    $_['entry_image']           = 'Image';
    $_['entry_store']           = 'Stores';
    $_['entry_status']          = 'Status';
    $_['entry_layout']          = 'Layout Override';
    // Error
    $_['error_warning']         = 'Warning: Please check the form carefully for errors!';
    $_['error_permission']      = 'Warning: You do not have permission to modify Recipes!';
    $_['error_image']           = 'Image required!';
    $_['error_name']            = 'Name must be between 3 and 255 characters!!';
    $_['error_author']          = 'Author name must be between 3 and 64 characters!!';
    $_['error_description']     = 'Description must be between 3 and 255 characters!!';
    $_['error_requeriment']     = 'Requeriment must be between 3 and 255 characters!!';
    $_['error_ingredient']      = 'Ingredient must be between 3 and 255 characters!!';
    $_['error_prep_time']       = 'Preparation time must be between 1 and 10 characters!!';
    $_['error_cook_time']       = 'Cook time must be between 1 and 10 characters!!';
    $_['error_preparation']     = 'Preparation must be between 3 and 255 characters!!';
    $_['error_tip']             = 'Tip must be between 3 and 255 characters!!';
    $_['error_store']           = 'Warning: This Recipe page cannot be deleted asits currently used by %s stores!!';
?>