<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Version
define('VERSION', '2.3.0.2');

// Configuration
if (is_file('config.php')) {
	require_once('config.php');
}
if (is_file('../app_config.php')) {
    require_once('../app_config.php');
}

// Startup
require_once(DIR_SYSTEM . 'startup.php');

start('admin');