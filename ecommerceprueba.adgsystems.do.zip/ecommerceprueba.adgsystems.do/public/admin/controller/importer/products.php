<?php
class ControllerImporterProducts extends Controller {

    public function index()
    {
        $this->document->setTitle('Importador de Productos');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $data['token'] = $this->session->data['token'];

        $this->response->setOutput($this->load->view('importer/products', $data, 'blade'));
    }

    public function load()
    {
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

            if ($this->request->post['tipo'] == 'text/csv') {
                try {
                    $file = $this->request->files['plantilla'];
                    $rows = $this->parseCsv($file['tmp_name']);
                    $products = array_splice($rows, 2);
                    $array['products'] = [];
                    $array['columns'] = [];

                    array_push($array['columns'], ['field' => 'numero', 'title' => 'Número']);
                    for ($i=0;$i<count($rows[0]);$i++) {
                        array_push($array['columns'], ['field' => $rows[0][$i], 'title' => $rows[1][$i]]);
                    }

                    $pcount = 1;
                    foreach ($products as $p) {
                        $a = [];
                        $a['numero'] = $pcount;
                        for ($i=0;$i<count($p)+1;$i++) {
                            if (isset($p[$i]) && isset($rows[0][$i])) {
                                $a[$rows[0][$i]] = $this->db->escape($p[$i]) ;
                            }
                        }
                        if (count($a) > 0) {
                            array_push($array['products'], $a);
                            $pcount++;
                        }
                    }

                    echo json_encode(['data'=>$array, 'table' =>  $this->load->view('importer/productstable', $array, 'blade')]);
                    exit();
                }catch (Exception $e) {
                    $this->errorResponse('CSV No pudo ser interpretado: '.$e->getMessage());
                }
            }

            $this->errorResponse('No se pudo procesar el tipo de plantilla seleccionado.');
        }
    }

    public function persistToDatabase()
    {
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
            $data = $this->request->post['products'];
            $this->load->model('catalog/product');
            $this->load->model('catalog/manufacturer');
            $errors = [];

            $availableLanguages = $this->getAvailableLanguageIds();
            $cantidad = count($data['products']);
            for ($i = 0; $i <  $cantidad; $i++) {
                try {
                    $res = $this->addSingleProduct($data['products'][$i], $availableLanguages);
                    if (is_numeric($res) !== true) {
                        $errors[$i+1] = $res;
                    }
                } catch (Exception $e) {
                    $errors[$i+1] = 'Error al procesar producto: ' .$e->getMessage();
                }
            }

            $totalprocessed = count($data['products']) - count($errors);
            echo json_encode(['errors' => $errors, 'total' => $totalprocessed ]); exit();
        }

        return $this->errorResponse('Metodo Incorrecto');
    }

    private function addSingleProduct($product, $lang)
    {
        if (isset($product['external_id']) && $this->checkExternalCode($product['external_id'])) {
            return 'Un producto con este código externo ya existe.';
        }

        $product = $this->expandProductWithFields($product, $lang);
        if (isset($product['brand'])) {

            if (!isset($product['brand']) || $product['brand'] == "") {
                $product['brand'] = "Genérico";
            }

            $brand_id = $this->getOrCreateManufacturer($product['brand']);
            $product['manufacturer'] = $product['brand'];
            $product['manufacturer_id'] = $brand_id;
            unset($product['brand']);
        }

        $res = $this->model_catalog_product->addProduct($product);
        return $res;
    }

    private function checkExternalCode ($code) {
        $result = $this->db->query('SELECT 1 FROM '.DB_PREFIX.'product WHERE external_id = "'.$this->db->escape($code).'"');
        return $result->num_rows > 0;
    }

    private function getOrCreateManufacturer ($manufacturer_name) {
        $result = $this->db->query(
            'SELECT manufacturer_id, name,sort_order FROM '.DB_PREFIX.'manufacturer WHERE name = "'.$this->db->escape($manufacturer_name).'"'
        );

        if ($result->num_rows > 0) {
            return $result->row['manufacturer_id'];
        }

        return $this->model_catalog_manufacturer->addManufacturer([
            'name' => $manufacturer_name,
            'sort_order' => 0,
            'manufacturer_store' => 0
        ]);
    }

    private function expandProductWithFields($product, $languages) {
        if (isset($product['name']) ) {
            $product['product_description'] = [];
            foreach ($languages as $l) {
                $product['product_description'][$l] = [
                    'name' => $product['name'],
                    'description' => isset($product['description']) ?  $product['description'] : "",
                    'meta_title' => $product['name'],
                    'meta_description' => isset($product['description']) ?  $product['description'] : "",
                    'meta_keyword' => $product['name'],
                    'tag' => ""
                ];
            }
            unset($product['name']); unset($product['description']);
        }
        $product['tax_class_id'] = 0; //default
        $product['stock_status_id'] = 7; //In_Stock
        $product['shipping'] = 1; //Required shipping
        $product['date_available'] = date('Y-m-d');
        $product['length_class_id'] = 1;
        $product['weight_class_id'] = 1;
        $product['status'] = 1;
        $product['sort_order'] = 1;
        $product['manufacturer'] = "";
        $product['manufacturer_id'] = 0;
        $product['category'] = "";
        $product['filter'] = "";
        $product['sku'] = "";
        $product['upc'] = "";
        $product['ean'] = "";
        $product['jan'] = "";
        $product['length'] = "";
        $product['width'] = "";
        $product['height'] = "";
        $product['keyword'] = "";
        $product['length'] = "";
        $product['location'] = "";
        $product['mpn'] = "";
        $product['weight'] = "";
        $product['isbn'] = "";
        $product['product_store'] = [0];
        $product['isbn'] = "";
        $product['download'] = "";
        $product['related'] = "";
        $product['option'] = "";
        if (!isset($product['image'])) {
            $product['image'] = "";
        }
        $product['points'] = "";

        return $product;
    }

    private function getAvailableLanguageIds(){
        $res = array();
        $rows = $this->db->query('SELECT language_id FROM oc_language')->rows;
        foreach ($rows as $r) {
            $res[]=$r['language_id'];
        }
        return $res;
    }

    private function getProductsStructure () {
        $res =  $this->db->query('SHOW COLUMNS FROM '.DB_PREFIX.'product');
        return array_map(function ($val) {
            return $val['Field'];
        }, $res->rows);
    }



    private function validateForm() {
        if (!isset($this->request->post['tipo'] ) || !isset($this->request->files['plantilla'] )) {
            return false;
        }
        return true;
    }

    private function parseCsv ($path) {
        $csvData = file_get_contents( $path );

        $lines = explode(PHP_EOL, $csvData);
        $header = $lines[0];
        if (!$this->plantillaHeaderValid($header)) {
            $this->errorResponse('El encabezado del archivo CSV no esta presente o no es el mismo de la plantilla.');
        }
        $array = array();
        foreach ($lines as $line) {
            if ($line !== "") {
                $array[] = str_getcsv($line);
            }
        }
        return $array;
    }

    private function plantillaHeaderValid ($header) {
        return true;
//        return $header == 'external_code,product_name,product_description,price,quantity,minimum,subtract,brand,model';
    }

    private function errorResponse ($message, $code = 500){
        http_response_code($code);
        echo $message; exit();
    }
}