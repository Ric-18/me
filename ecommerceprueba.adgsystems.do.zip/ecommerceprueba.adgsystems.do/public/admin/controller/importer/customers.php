<?php
class ControllerImporterCustomers extends Controller {

    public function index ()
    {
        $this->document->setTitle('Importador de Clientes');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $data['token'] = $this->session->data['token'];

        $this->response->setOutput($this->load->view('importer/customers', $data, 'blade'));
    }

}