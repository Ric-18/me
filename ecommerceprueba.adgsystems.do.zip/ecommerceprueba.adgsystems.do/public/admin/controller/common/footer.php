<?php
class ControllerCommonFooter extends Controller {
	public function index() {
		$this->load->language('common/footer');

		$data['text_footer'] = "<a href='https://adgsystems.com.do'>ADGSystems®</a>  Ecommerce  ©2017";

        $data['text_version'] = '';
		return $this->load->view('common/footer', $data);
	}
}
