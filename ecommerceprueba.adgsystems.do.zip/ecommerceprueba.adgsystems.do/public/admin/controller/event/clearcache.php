<?php
class ControllerEventClearcache extends Model {

    public function index() {

        $this->cache_settings_manager->resetClientSettings();
//        if (!$this->cache_settings_manager->resetClientSettings()) {
//            die('Operation succesfull, but could not refresh cache.');
//        }
    }
}
